import 'package:flutter/material.dart';

class RegisterScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Register'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Image.asset('assets/register_image.png'),
            TextField(
              decoration: InputDecoration(labelText: 'Enter your Name'),
            ),
            TextField(
              decoration: InputDecoration(labelText: 'Enter your Email'),
            ),
            TextField(
              decoration: InputDecoration(labelText: 'Enter your Password'),
              obscureText: true,
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                Navigator.pushReplacementNamed(context, '/home');
              },
              child: Text('Register'),
            ),
            TextButton(
              onPressed: () {},
              child: Text('Or OneTap SignIn with Google'),
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Sky Learns'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text(
              'Hi Learner!',
              style: TextStyle(fontSize: 24),
            ),
            Text('Today is a good day to start learning.'),
            SizedBox(height: 16.0),
            Expanded(
              child: GridView.count(
                crossAxisCount: 2,
                children: [
                  _buildCourseCard(context, 'Leet Code'),
                  _buildCourseCard(context, 'Web Dev'),
                  _buildCourseCard(context, 'Go Lang'),
                  _buildCourseCard(context, 'Bonus'),
                ],
              ),
            ),
            Text('Announcements:'),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.school), label: 'Courses'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
        onTap: (index) {
          if (index == 1) {
            Navigator.pushNamed(context, '/profile');
          }
        },
      ),
    );
  }

  Widget _buildCourseCard(BuildContext context, String courseName) {
    return Card(
      child: InkWell(
        onTap: () {
          Navigator.pushNamed(context, '/course_detail');
        },
        child: Center(
          child: Text(courseName),
        ),
      ),
    );
  }
}

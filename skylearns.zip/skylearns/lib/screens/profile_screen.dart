import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profile'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text(
              'Hi learner!',
              style: TextStyle(fontSize: 24),
            ),
            Text('Hope, We are able to contribute to your knowledge.'),
            SizedBox(height: 16.0),
            ListTile(
              title: Text('Mail us your suggestions'),
            ),
            ListTile(
              title: Text('Rate Us 5 Star on Play Store.'),
            ),
            ListTile(
              title: Text('Check out our other Apps.'),
            ),
            Spacer(),
            ElevatedButton(
              onPressed: () {
                Navigator.pushReplacementNamed(context, '/login');
              },
              child: Text('LOGOUT'),
            ),
          ],
        ),
      ),
    );
  }
}

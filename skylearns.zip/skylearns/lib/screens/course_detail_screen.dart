
import 'package:flutter/material.dart';

class CourseDetailScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('LEET CODE'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          Text(
            'Problems are in sequence and solved with better approaches.',
            style: TextStyle(fontSize: 16),
          ),
          SizedBox(height: 16.0),
          _buildProblemCard(context, 'Leet Code Problem 1'),
          _buildProblemCard(context, 'Leet Code Problem 2'),
          _buildProblemCard(context, 'Leet Code Problem 3'),
          _buildProblemCard(context, 'Leet Code Problem 4'),
        ],
      ),
    );
  }

  Widget _buildProblemCard(BuildContext context, String problemName) {
    return Card(
      child: ListTile(
        title: Text(problemName),
        onTap: () {
          Navigator.pushNamed(context, '/video');
        },
      ),
    );
  }
}

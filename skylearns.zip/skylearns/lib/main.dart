import 'package:flutter/material.dart';
import 'screens/register_screen.dart';
import 'screens/login_screen.dart';
import 'screens/home_screen.dart';
import 'screens/course_detail_screen.dart';
import 'screens/video_screen.dart';
import 'screens/profile_screen.dart';

void main() {
  runApp(SkyLearnsApp());
}

class SkyLearnsApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Sky Learns',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => RegisterScreen(),
        '/login': (context) => LoginScreen(),
        '/home': (context) => HomeScreen(),
        '/course_detail': (context) => CourseDetailScreen(),
        '/video': (context) => VideoScreen(),
        '/profile': (context) => ProfileScreen(),
      },
    );
  }
}

package com.example.skylearns

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
